

module.exports = {

    var GOOGLE_CLIENT_ID = '932569619900-24714d0s0kddfcs5hebhnl6tj2qv87rc.apps.googleusercontent.com';
    var GOOGLE_CLIENT_SECRET = '0A8iooj3l2wMKx3Iv__NvYVv';

    var connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'zakiS132024!!',
        database: 'tickets_app'
    });

}


